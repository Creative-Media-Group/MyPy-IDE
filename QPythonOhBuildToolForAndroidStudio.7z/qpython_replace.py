src='org.qpython.qpy'
dst='com.hipipal.qpyplus'
swp='C:/Users/Administrator/Desktop/resource3~/'

import os,shutil
file=__file__.replace('\\',"/")
pth=file[:file.rfind('/')+1]

def rpl(x):
    a=swp+x
    b=os.listdir(a)
    for c in b:
        d=x+c
        e=swp+d
        if os.path.isdir(e):
            if c=='__pycache__':
                shutil.rmtree(e)
                print('remove:'+e)
                continue
            rpl(d+'/')
        else:
            try:
                g=open(e).read()
                if g.find(src)!=-1 and g.find('乘着船')==-1:
                    print('change:'+d)
                    h=g.replace(src,dst)
                    open(e,'w').write(h)
            except:
                pass

p='C:/Users/Administrator/Documents/QPythonOriBuild/qpython-'
q=p+'hipipal'
p+='origin'

if os.path.exists(q):
    print('remove old',q)
    shutil.rmtree(q)

print('replacing ……')
rpl('')

print('copy',p,"-->",q)
shutil.copytree(p,q)

print('ol --> oh')
r=q+'/qpython/build.gradle'
s=open(r,encoding='utf-8').read()
t=s.replace(src,dst).replace('ol {','oh {')
open(r,'w',encoding='utf-8').write(t)
r=q+'/qpython/src/'
shutil.move(r+'ol',r+'oh')
r=q+'/qpython/agconnect-services.json'
s=open(r,encoding='utf-8').read()
t=s.replace(src,dst)
open(r,'w',encoding='utf-8').write(t)
shutil.rmtree(q+'/qpython/ol')
print('Done')


