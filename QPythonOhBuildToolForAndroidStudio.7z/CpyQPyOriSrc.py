import os,shutil,time
isdir=os.path.isdir
listdir=os.listdir
mkdir=os.mkdir
rmdir=os.rmdir
remove=os.remove
copy=shutil.copy
rmtree=shutil.rmtree

notNeed='build','.gradle','.idea','release','debug',".git",".github",'.cxx'
notNeed2='hs_err_pid','replay_pid'
src='C:\\Users\\Administrator\\Documents\\QPythonOriBuild\\qpython-origin'
dst=src+'-copy'
def g(f,x):
    try:
        f(x)
    except:
        pass
def Now():
    t=time.localtime()
    return "-%04d%02d%02d-%02d%02d%02d"%(t.tm_year,t.tm_mon,t.tm_mday,t.tm_hour,t.tm_min,t.tm_sec)
g(rmtree,dst)
zipF=src+Now()+'.7z'
#g(remove,zipF)

n=0
def f(x=''):
    global n
    s=src+x
    t=dst+x
    mkdir(t)
    for i in listdir(s):
        j=s+'/'+i
        k=x+'/'+i
        if isdir(j):
            if i in notNeed:
                print('ex',k)
                continue
            f(k)
        else:
            for u in notNeed2:
                if i.find(u)==0:
                    print('ex',i)
                    break
            else:
                copy(j,t+'/'+i)
                n+=1
    try:
        rmdir(t)
        print('re',x)
    except:
        if x=='':
            print('am',n)
f()

zipE='"C:\\Program Files\\7-Zip\\7z.exe" '
cmd=zipE+'a '+zipF+' '+dst+'\\* -mx9'
os.system(cmd)
g(rmtree,dst)

import time
time.sleep(3)
